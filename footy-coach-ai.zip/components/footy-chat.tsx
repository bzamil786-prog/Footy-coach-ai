"use client"

import { FormEvent, useEffect, useRef, useState } from "react"
import { ArrowUp, Bot, Mic, Square, User } from "lucide-react"
import { InputGroup, InputGroupAddon, InputGroupButton, InputGroupTextarea } from "@/components/ui/input-group"
import { getCoachAnswer } from "@/lib/footy-knowledge"

type SpeechRecognitionResultEvent = Event & {
  results: {
    [index: number]: { [index: number]: { transcript: string } }
    length: number
  }
}

type SpeechRecognitionErrorEvent = Event & { error: string }

type SpeechRecognitionInstance = EventTarget & {
  lang: string
  continuous: boolean
  interimResults: boolean
  start: () => void
  stop: () => void
  onresult: ((event: SpeechRecognitionResultEvent) => void) | null
  onerror: ((event: SpeechRecognitionErrorEvent) => void) | null
  onend: (() => void) | null
}

type SpeechRecognitionConstructor = new () => SpeechRecognitionInstance

type ChatMessage = {
  id: string
  role: "user" | "assistant"
  text: string
}

const answers = [
  {
    terms: ["offside"],
    answer: "Offside stops attackers from waiting beside the goal. When a teammate plays the ball, an attacker cannot be nearer to the goal line than both the ball and the second-last opponent—and then become involved in play. Being level is onside.",
  },
  {
    terms: ["goalkeeper", "goalie", "keeper"],
    answer: "The goalkeeper protects the goal and is the only player allowed to handle the ball, but only inside their own penalty area. They also organize defenders and start attacks with throws or passes.",
  },
  {
    terms: ["formation", "4-4-2", "4 4 2"],
    answer: "A formation describes how a team is arranged. In a 4-4-2, there are four defenders, four midfielders, and two forwards. The goalkeeper is not included in those numbers.",
  },
  {
    terms: ["penalty", "penalty kick"],
    answer: "A penalty kick is awarded when a defending player commits a direct-free-kick offence inside their own penalty area. One attacker shoots from the penalty spot with only the goalkeeper defending the goal.",
  },
  {
    terms: ["free kick", "freekick"],
    answer: "A free kick restarts play after a foul. A direct free kick can be scored straight into the goal; an indirect free kick must touch another player before a goal can count.",
  },
  {
    terms: ["corner", "corner kick"],
    answer: "A corner is awarded when the defending team last touches the ball before it crosses their own goal line without a goal being scored. The attacking team kicks from the nearest corner arc.",
  },
  {
    terms: ["yellow card", "red card", "card"],
    answer: "A yellow card is a formal warning. Two yellows in one match become a red card. A red card sends the player off, and their team normally plays the rest of the match with one fewer player.",
  },
  {
    terms: ["midfielder", "midfield"],
    answer: "Midfielders connect defence and attack. They help win the ball, control possession, create chances, and support teammates across the middle of the pitch.",
  },
  {
    terms: ["striker", "forward"],
    answer: "A striker or forward plays mainly to create and score goals. They make runs behind defenders, hold up the ball, and find space in the penalty area.",
  },
  {
    terms: ["defender", "centre back", "center back", "fullback", "full-back"],
    answer: "Defenders protect their goal by marking attackers, blocking shots, winning tackles, and clearing danger. Centre-backs play centrally, while full-backs defend the wide areas.",
  },
]

function getCoachAnswer(question: string) {
  const normalized = question.toLowerCase()
  const match = answers.find(item => item.terms.some(term => normalized.includes(term)))
  if (match) return `${match.answer}\n\nAsk me another football rule, position, or tactic.`

  return "I’m the free, built-in version of FootyCoach, so I currently know the most common football topics. Try asking about offside, formations, penalties, free kicks, cards, corners, goalkeepers, defenders, midfielders, or strikers."
}

export function FootyChat() {
  const [input, setInput] = useState("")
  const [isListening, setIsListening] = useState(false)
  const [voiceError, setVoiceError] = useState("")
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const recognitionRef = useRef<SpeechRecognitionInstance | null>(null)

  useEffect(() => () => recognitionRef.current?.stop(), [])

  function toggleVoiceInput() {
    if (isListening) {
      recognitionRef.current?.stop()
      return
    }

    const speechWindow = window as typeof window & {
      SpeechRecognition?: SpeechRecognitionConstructor
      webkitSpeechRecognition?: SpeechRecognitionConstructor
    }
    const Recognition = speechWindow.SpeechRecognition ?? speechWindow.webkitSpeechRecognition

    if (!Recognition) {
      setVoiceError("Voice input isn’t supported in this browser. Try Chrome, Edge, or Safari.")
      return
    }

    setVoiceError("")
    const recognition = new Recognition()
    recognition.lang = navigator.language || "en-GB"
    recognition.continuous = false
    recognition.interimResults = false
    recognition.onresult = event => {
      const transcript = event.results[0]?.[0]?.transcript?.trim()
      if (transcript) setInput(current => [current.trim(), transcript].filter(Boolean).join(" "))
    }
    recognition.onerror = event => {
      if (event.error !== "aborted") {
        setVoiceError(event.error === "not-allowed" ? "Microphone access was denied. Allow it in your browser settings and try again." : "I couldn’t hear that clearly. Please try again.")
      }
      setIsListening(false)
    }
    recognition.onend = () => setIsListening(false)
    recognitionRef.current = recognition
    setIsListening(true)
    recognition.start()
  }

  function submit(event: FormEvent) {
    event.preventDefault()
    const text = input.trim()
    if (!text) return

    setMessages(current => [
      ...current,
      { id: crypto.randomUUID(), role: "user", text },
      { id: crypto.randomUUID(), role: "assistant", text: getCoachAnswer(text) },
    ])
    setInput("")
  }

  return (
    <section id="ask" className="bg-primary py-20 text-primary-foreground sm:py-28">
      <div className="mx-auto grid max-w-7xl gap-12 px-5 md:px-8 lg:grid-cols-[0.7fr_1.3fr] lg:items-start">
        <div className="flex flex-col gap-5 lg:sticky lg:top-28"><p className="font-mono text-xs font-bold uppercase tracking-widest text-accent">Your turn</p><h2 className="text-balance text-4xl font-bold tracking-tight sm:text-5xl">Ask the question behind the question.</h2><p className="text-pretty leading-relaxed text-primary-foreground/70">Rules, formations, competitions, player roles—if it happens on a football pitch, FootyCoach can make it click.</p></div>
        <div className="overflow-hidden rounded-[2rem] bg-background text-foreground shadow-2xl">
          <div className="flex items-center gap-3 border-b border-border px-5 py-4"><span className="flex size-10 items-center justify-center rounded-full bg-primary text-primary-foreground"><Bot aria-hidden="true" /></span><div><p className="font-bold">FootyCoach</p><p className="text-xs text-muted-foreground">Ready when you are</p></div></div>
          <div role="log" aria-live="polite" className="flex min-h-[24rem] max-h-[34rem] flex-col gap-5 overflow-y-auto p-5 sm:p-7">
            {messages.length === 0 && <div className="my-auto flex flex-col items-center gap-3 text-center"><span className="flex size-14 items-center justify-center rounded-full bg-secondary"><Bot className="text-primary" aria-hidden="true" /></span><h3 className="text-xl font-bold">What are we figuring out?</h3><p className="max-w-sm text-sm leading-relaxed text-muted-foreground">Try “Explain offside like I&apos;m five” or ask about something happening in the match right now.</p></div>}
            {messages.map(message => <div key={message.id} className={`flex gap-3 ${message.role === "user" ? "flex-row-reverse" : ""}`}><span className={`flex size-8 shrink-0 items-center justify-center rounded-full ${message.role === "user" ? "bg-accent text-accent-foreground" : "bg-primary text-primary-foreground"}`}>{message.role === "user" ? <User aria-hidden="true" /> : <Bot aria-hidden="true" />}</span><div className={`max-w-[82%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${message.role === "user" ? "rounded-tr-sm bg-accent text-accent-foreground" : "rounded-tl-sm bg-secondary"}`}><p className="whitespace-pre-wrap">{message.text}</p></div></div>)}
          </div>
          <form onSubmit={submit} className="border-t border-border p-4 sm:p-5">
            <InputGroup className="min-h-24 rounded-2xl bg-secondary">
              <InputGroupTextarea value={input} onChange={event => setInput(event.target.value)} onKeyDown={event => { if (event.key === "Enter" && !event.shiftKey && !event.nativeEvent.isComposing && event.keyCode !== 229) { event.preventDefault(); event.currentTarget.form?.requestSubmit() } }} placeholder={isListening ? "Listening…" : "Ask anything about football…"} aria-label="Your football question" />
              <InputGroupAddon align="block-end" className="justify-between">
                <div className="flex items-center gap-2">
                  <InputGroupButton type="button" size="icon-sm" variant={isListening ? "secondary" : "ghost"} onClick={toggleVoiceInput} aria-label={isListening ? "Stop voice input" : "Start voice input"} aria-pressed={isListening}>
                    {isListening ? <Square /> : <Mic />}
                  </InputGroupButton>
                  <span className="text-xs text-muted-foreground" aria-live="polite">{isListening ? "Listening… tap to stop" : "Tap to speak"}</span>
                </div>
                <InputGroupButton type="submit" size="icon-sm" variant="default" disabled={!input.trim()} aria-label="Send question"><ArrowUp /></InputGroupButton>
              </InputGroupAddon>
            </InputGroup>
            {voiceError && <p role="alert" className="px-2 pt-2 text-sm text-destructive">{voiceError}</p>}
          </form>
        </div>
      </div>
    </section>
  )
}
